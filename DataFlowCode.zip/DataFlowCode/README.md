This project is to get the top 2 scores for each user.
The input file is gs://dataflow-samples/game/gaming_data*.csv
The columns are user, team, score, timestamp.
The output will be user_top2_score table in BigQuery.

Requirement for running the code:
1. Open an acount for Google Cloud Platform, install Google Cloud SDK, and create credentials for API
2. In google console, create a new project name first game, then go to the API manager to enable the DataFlow API. In google storage, create a new bucket for first-game project. Go to BigQuery, create a dataset, which is like a schema in relational database. The output data will be stored as tables in this BigQuery.
3. Java 1.8 and Maven are installed in your machine. Set up JAVA_HOME environment and add Maven bin directory to the path.
4. In termainal, change directory to this DataFlowCode directory which has pom.xml file.
5. Run the following command, if your project id, google storage name, BigQuery dataset name is different than the following command, please modify the command:
mvn compile exec:java -Dexec.mainClass=cscie63.dataflow.topscore.Top2Score -Dexec.args="--project=first-game-167101 --stagingLocation=gs://first-game2/staging/ --dataset=first_dataset --runner=BlockingDataflowPipelineRunner"